import type React from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface AboutSectionProps {
  className?: string
}

const AboutSection: React.FC<AboutSectionProps> = ({ className }) => {
  return (
    <div className={cn("text-foreground", className)}>
      <h2 className="text-3xl md:text-4xl font-bold text-accent mb-12 text-center">About Me</h2>
      <div className="flex flex-col lg:flex-row items-center lg:items-start gap-8 lg:gap-12">
        {/* Profile Picture */}
        <div className="flex-shrink-0">
          <div className="relative">
            <div className="w-64 h-64 md:w-80 md:h-80 rounded-full border-4 border-[#00A79D] overflow-hidden bg-gray-800 flex items-center justify-center">
              <Image
                src="/placeholder.svg?height=320&width=320"
                alt="Anojan Yogenthiran - AI/ML Engineer"
                width={320}
                height={320}
                className="w-full h-full object-cover"
                priority
              />
            </div>
          </div>
        </div>

        {/* About Text */}
        <div className="flex-1 space-y-6 text-lg md:text-xl leading-relaxed">
          <p>
            I'm an AI/ML engineer specializing in deep learning, natural language processing, and computer vision. With
            over 5 years of experience, I've developed and deployed machine learning systems that serve millions of
            users, from recommendation engines to autonomous decision-making platforms. My expertise spans the entire ML
            lifecycle, from research and experimentation to production deployment and monitoring.
          </p>
          <p>
            When I'm not training neural networks or optimizing model performance, you'll find me contributing to
            open-source projects, writing technical articles, or exploring the latest research papers. I'm passionate
            about making AI more accessible and interpretable, and I believe in the power of technology to create
            positive impact in the world.
          </p>
          <p>
            I hold a Master's degree in Computer Science with a focus on Machine Learning, and I'm always eager to
            tackle new challenges in the rapidly evolving field of artificial intelligence.
          </p>
        </div>
      </div>
    </div>
  )
}

export default AboutSection
